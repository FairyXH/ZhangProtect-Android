am start -n com.web.czero/com.web.czero.MainActivity >/dev/null 2>&1
