MODDIR=${0%/*}
CONFIG="$MODDIR/config.json"

config_enabled() {
    grep -qE "\"$1\"[[:space:]]*:[[:space:]]*true" "$CONFIG" 2>/dev/null
}

has_prop() {
    [ -n "$(getprop "$1" 2>/dev/null)" ]
}

config_enabled "disable_vendor_guard" || exit 0
[ "$(cat /data/system/czero_freeze_native 2>/dev/null)" = "1" ] || exit 0
if has_prop persist.sys.gz.enable || has_prop persist.sys.powmillet.enable ||
    [ -x /system/bin/millet_monitor ] || [ -x /system_ext/bin/millet_monitor ]; then
    resetprop -n persist.sys.gz.enable false
    resetprop -n persist.sys.powmillet.enable false
    resetprop -n persist.sys.brightmillet.enable false
    resetprop -n sys.millet.monitor 1
    resetprop -n sys.millet.handshake true
fi

if has_prop persist.vendor.enable.hans || [ -x /system/bin/hans ]; then
    resetprop -n persist.vendor.enable.hans false
    resetprop -n sys.hans.enable true
fi
