#!/system/bin/sh
   MODDIR=${0%/*}
   chmod -R 755 "$MODDIR"
   find "$MODDIR" -type f \( -name '*.prop' -o -name '*.json' -o -name '*.log' -o -name '*.md' -o -name '*.txt' \) -exec chmod 644 {} + 2>/dev/null
   "$MODDIR/service" > /dev/null 2>&1 &
   pkill -f timer_daemon
   sleep 3
   setsid "$MODDIR/cron/timer_daemon" > /dev/null 2>&1 &
   (
       n=0
       while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$n" -lt 150 ]; do
           sleep 2
           n=$((n + 1))
       done
       if [ "$(getprop sys.boot_completed)" = "1" ]; then
           "$MODDIR/list/customize" reconcile-stats >/dev/null 2>&1
           if grep -qE '"auto_enable"[[:space:]]*:[[:space:]]*true' "$MODDIR/config.json" 2>/dev/null; then
               if [ "$(cat /data/system/czero_freeze_native 2>/dev/null)" = "1" ]; then
                   settings put global cached_apps_freezer enabled
                   device_config put activity_manager_native_boot use_freezer true
               else
                   settings put global cached_apps_freezer default
                   device_config delete activity_manager_native_boot use_freezer
               fi
           fi
           sleep 8
           am broadcast -n com.web.czero/com.web.czero.core.notify.CleanEventReceiver --es phase deploy >/dev/null 2>&1
       fi
   ) > /dev/null 2>&1 &
