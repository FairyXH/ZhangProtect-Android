#!/system/bin/sh
read_key_timeout() {
    local tmp="$MODPATH/.czero_key.tmp"
    getevent -qlc 1 >"$tmp" 2>/dev/null &
    local pid=$! n=0
    while [ "$n" -lt "$1" ] && kill -0 "$pid" 2>/dev/null; do
        sleep 1
        n=$((n + 1))
    done
    kill "$pid" 2>/dev/null
    cat "$tmp" 2>/dev/null
    rm -f "$tmp"
}

clear_key_events() {
    read_key_timeout 1 >/dev/null
}

volume_key_detection() {
    clear_key_events
    local tries=0 key=""
    while [ "$tries" -lt 12 ]; do
        key=$(read_key_timeout 5 |
            awk '/KEY_VOLUMEUP/ {print "UP"; exit}
                 /KEY_VOLUMEDOWN/ {print "DOWN"; exit}')
        [ -n "$key" ] && break
        tries=$((tries + 1))
    done
    case "$key" in
        UP)   return 0 ;;
        DOWN) return 1 ;;
        *)    return 2 ;;
    esac
}

choose_language() {
    ui_print " "
    ui_print "==================================="
    ui_print " Select Language / 选择语言 "
    ui_print "-----------------------------------"
    ui_print " [+] Volume Up   = English"
    ui_print " [-] Volume Down = 中文"
    ui_print "==================================="
    volume_key_detection
    case $? in
        0) UI_LANG=en ;;
        1) UI_LANG=zh ;;
        *) UI_LANG=zh; ui_print " (No key detected, default 中文)" ;;
    esac
}

show_menu() {
    ui_print " "
    ui_print "-----------------------------------"
    ui_print " $1 "
    [ -n "$2" ] && ui_print " $2 "
    ui_print "-----------------------------------"
    ui_print "1. [$L_AGREE] - $L_VOLUP"
    ui_print "2. [$L_CANCEL] - $L_VOLDOWN"
}

handle_choice() {
    volume_key_detection
    case $? in
        0) ui_print "$L_CHOSE$1"; return 0 ;;
        *) ui_print "$L_CHOSE$2"; return 1 ;;
    esac
}


merge_config() {
    _old="$1"; _new="$2"; _out="$3"; _awk="$MODPATH/.merge.awk"
    cat >"$_awk" <<'MERGE_AWK'
function keyof(line,   a) {
    if (match(line, /^[ \t]*"[^"]+"[ \t]*:/)) {
        a = line
        sub(/^[ \t]*"/, "", a)
        sub(/"[ \t]*:.*$/, "", a)
        return a
    }
    return ""
}
function braces(line,   i, ch, instr, esc, d) {
    d = 0; instr = 0; esc = 0
    for (i = 1; i <= length(line); i++) {
        ch = substr(line, i, 1)
        if (esc) { esc = 0; continue }
        if (ch == "\\") { esc = 1; continue }
        if (ch == "\"") { instr = !instr; continue }
        if (instr) continue
        if (ch == "{") d++
        else if (ch == "}") d--
    }
    return d
}
FNR == NR {
    k = keyof($0); kd = depth
    if (sect == "" && kd == 1 && k != "" && $0 ~ /\{[ \t]*$/) {
        sect = k; nsect[++nsects] = k; blen[sect] = 0
    }
    if (sect != "") {
        block[sect, ++blen[sect]] = $0
        if (kd == 2 && k != "") { n = ++cnt[sect]; nkey[sect, n] = k; nline[sect, n] = $0 }
    }
    depth += braces($0)
    if (sect != "" && depth == 1) sect = ""
    next
}
FNR == 1 { depth = 0; sect = "" }
{
    old[++nold] = $0
    k = keyof($0); kd = depth
    if (kd == 1 && k != "") hassect[k] = 1
    if (sect == "" && kd == 1 && k != "" && $0 ~ /\{[ \t]*$/) { sect = k; opens[nold] = k }
    else if (sect != "" && kd == 2 && k != "") have[sect, k] = 1
    depth += braces($0)
    if (sect != "" && depth == 1) sect = ""
}
END {
    for (i = 1; i <= nold; i++) {
        print old[i]
        if (i == 1 && old[i] ~ /^[ \t]*\{[ \t]*$/) {
            for (s = 1; s <= nsects; s++) {
                name = nsect[s]
                if (hassect[name]) continue
                for (j = 1; j <= blen[name]; j++) {
                    line = block[name, j]
                    if (j == blen[name]) { sub(/,[ \t]*$/, "", line); line = line "," }
                    print line
                }
            }
        }
        s = opens[i]
        if (s != "") {
            for (j = 1; j <= cnt[s]; j++) {
                k = nkey[s, j]
                if (have[s, k]) continue
                line = nline[s, j]
                sub(/,[ \t]*$/, "", line)
                print line ","
            }
        }
    }
}
MERGE_AWK
    awk -f "$_awk" "$_new" "$_old" >"$_out" 2>/dev/null
    rm -f "$_awk"
    [ -s "$_out" ] || return 1
    grep -q '"gc"' "$_out" || return 1
    _ob=$(tr -cd '{' <"$_out" | wc -c)
    _cb=$(tr -cd '}' <"$_out" | wc -c)
    [ "$_ob" -eq "$_cb" ] || return 1
    return 0
}

# 把新版默认白名单里、用户白名单按名字还没有的分组补进去。只加不删，失败时用户文件不变
merge_groups() {
    _bin="$MODPATH/list/customize"
    [ -f "$_bin" ] && [ -f "$1" ] && [ -f "$2" ] || return 1
    chmod 0755 "$_bin"
    _out=$("$_bin" merge-groups "$1" "$2" 2>/dev/null)
    case "$_out" in
        "merged 0") ;;
        merged*) ui_print "  $L_WLMERGED ${2##*/}" ;;
    esac
    return 0
}

prop_to_json() {
    _src="$1"; _dst="$2"; _tmp="$_dst.tmp"; _awk="$MODPATH/.prop2json.awk"
    cat >"$_awk" <<'PROP_AWK'
function esc(s,   out, i, c) {
    out = ""
    for (i = 1; i <= length(s); i++) {
        c = substr(s, i, 1)
        if (c == "\\") out = out "\\\\"
        else if (c == "\"") out = out "\\\""
        else out = out c
    }
    return out
}
function flush(   i) {
    if (np == 0) return
    if (ng++) printf ",\n"
    printf "    {\n      \"name\": \"%s\",\n      \"enabled\": true,\n      \"paths\": [\n", esc(gname)
    for (i = 1; i <= np; i++) printf "        \"%s\"%s\n", esc(paths[i]), (i < np ? "," : "")
    printf "      ]\n    }"
    np = 0
}
BEGIN { ng = 0; np = 0; gname = ""; print "{"; print "  \"version\": 1,"; print "  \"groups\": [" }
{
    line = $0
    sub(/^[ \t\r]+/, "", line)
    sub(/[ \t\r]+$/, "", line)
    if (line == "") next
    if (substr(line, 1, 1) == "#") {
        flush()
        sub(/^#+[ \t]*/, "", line)
        gname = line
        next
    }
    paths[++np] = line
}
END { flush(); if (ng) printf "\n"; print "  ]"; print "}" }
PROP_AWK
    awk -f "$_awk" "$_src" >"$_tmp" 2>/dev/null
    rm -f "$_awk"
    [ -s "$_tmp" ] || { rm -f "$_tmp"; return 1; }
    mv -f "$_tmp" "$_dst"
    return 0
}

choose_language
if [ "$UI_LANG" = "en" ]; then
    L_AGREE="Agree";   L_CANCEL="Cancel"
    L_VOLUP="Volume Up"; L_VOLDOWN="Volume Down"
    L_CHOSE="You chose: "
    L_BANNER="CZero Installer"
    L_INHERIT_Q="Inherit previous config and black/white lists?"
    L_INHERIT_SUB="New options are merged in automatically"
    L_NOCFG="Config not found; maybe the module was never installed"
    L_CFGMERGED="Config inherited, new options merged in"
    L_CFGBAD="Old config unreadable; using defaults"
    L_MIGRATED="Converted old list to JSON:"
    L_WLMERGED="Added new default whitelist groups to:"
    L_DONE="Installation complete"
    L_NEEDAPP="The CZeroX app is required to configure this module"
    L_NEEDAPP2="Make sure it is installed and up to date"
    L_REBOOT="Reboot to activate the module"
    L_OPENURL="Opening the download page:"
    L_APPINSTALLED="CZeroX app installed"
    L_APPINSTALLING="Installing the CZeroX app..."
else
    L_AGREE="同意";   L_CANCEL="取消"
    L_VOLUP="音量键上"; L_VOLDOWN="音量键下"
    L_CHOSE="您选择了："
    L_BANNER="CZero 安装程序"
    L_INHERIT_Q="是否继承以往的配置和黑白名单？"
    L_INHERIT_SUB="新版新增的配置项会自动补全"
    L_NOCFG="未找到配置文件，可能是还未安装过模块"
    L_CFGMERGED="已继承配置，并补全新增项"
    L_CFGBAD="旧配置无法解析，改用默认配置"
    L_MIGRATED="旧列表已转为 JSON："
    L_WLMERGED="已补入新版默认白名单分组："
    L_DONE="安装配置完成"
    L_NEEDAPP="模块需配合 CZeroX 应用使用"
    L_NEEDAPP2="请确认已安装，且为最新版本"
    L_REBOOT="重启后模块才会生效"
    L_OPENURL="正在打开下载页："
    L_APPINSTALLED="CZeroX 应用已安装"
    L_APPINSTALLING="正在安装 CZeroX 应用..."
fi

ui_print " "
ui_print "==================================="
ui_print "   $L_BANNER   "
ui_print "==================================="

# 继承配置
show_menu "$L_INHERIT_Q" "$L_INHERIT_SUB"
if handle_choice "$L_AGREE" "$L_CANCEL"; then
    if [ -f "/data/adb/modules/CZero/config.json" ]; then
        OLD="/data/adb/modules/CZero"
        if merge_config "$OLD/config.json" "$MODPATH/config.json" "$MODPATH/.config.merged"; then
            mv -f "$MODPATH/.config.merged" "$MODPATH/config.json"
            ui_print "  $L_CFGMERGED"
        else
            rm -f "$MODPATH/.config.merged"
            ui_print "  $L_CFGBAD"
        fi
        rm -f "$OLD/config.json"
        for rel in \
            "list/app.json" \
            "list/suppress/apps.json" \
            "list/filesort/sources.json"; do
            [ -f "$OLD/$rel" ] && mv -f "$OLD/$rel" "$MODPATH/$rel"
        done
        for rel in \
            "list/clean_paths" \
            "list/clean_whitelist" \
            "list/Emptyfolder/directories" \
            "list/Emptyfolder/emptyfolder_white"; do
            _defaults=""
            case "$rel" in
                */clean_whitelist|*/emptyfolder_white)
                    _defaults="$MODPATH/$rel.json.default"
                    cp -f "$MODPATH/$rel.json" "$_defaults" 2>/dev/null || _defaults=""
                    ;;
            esac
            if [ -f "$OLD/$rel.json" ]; then
                mv -f "$OLD/$rel.json" "$MODPATH/$rel.json"
            elif [ -f "$OLD/$rel.prop" ]; then
                if prop_to_json "$OLD/$rel.prop" "$MODPATH/$rel.json"; then
                    ui_print "  $L_MIGRATED ${rel##*/}.json"
                fi
                rm -f "$OLD/$rel.prop"
            fi
            if [ -n "$_defaults" ]; then
                merge_groups "$_defaults" "$MODPATH/$rel.json"
                rm -f "$_defaults"
            fi
        done
    else
        ui_print "$L_NOCFG"
    fi
fi

if [ -d "/data/adb/modules/CZero/basis" ]; then
    mv -f "/data/adb/modules/CZero/basis" "$MODPATH/"
fi

DOWNLOAD_URL="https://czeropage.top/download-home"
APP_INSTALLED=0
APK_PATH="$MODPATH/app.apk"
if [ -f "$APK_PATH" ]; then
    ui_print " "
    ui_print "$L_APPINSTALLING"
    if pm install -r "$APK_PATH" >/dev/null 2>&1; then
        APP_INSTALLED=1
    fi
    rm -f "$APK_PATH"
fi

ui_print " "
ui_print "==================================="
ui_print "   $L_DONE   "
ui_print "==================================="
ui_print " "
if [ "$APP_INSTALLED" -eq 1 ]; then
    ui_print "-----------------------------------"
    ui_print " [OK] $L_APPINSTALLED "
    ui_print "      $L_REBOOT "
    ui_print "-----------------------------------"
else
    ui_print "-----------------------------------"
    ui_print " [!] $L_NEEDAPP "
    ui_print "     $L_NEEDAPP2 "
    ui_print "     $L_REBOOT "
    ui_print "-----------------------------------"
    ui_print " "
    ui_print "$L_OPENURL"
    ui_print "$DOWNLOAD_URL"
fi
exit 0